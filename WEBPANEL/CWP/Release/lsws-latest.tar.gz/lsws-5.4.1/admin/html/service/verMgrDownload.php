<h2>Version Management - Downloading New Release</h2>
<p class="xtbl_value"><a target=_new href="https://www.litespeedtech.com/products/litespeed-web-server/release-log">Release Notes</a>
	 </p>
<?php
if ($act != 'download')
	return; //illegal entrance
?>

<div style='height:80px;'></div>

<center>
Downloading In-Progress, this may take a few minutes ...<br><br>
... Please wait ...
<img src='/static/images/working.gif' onload="vermgr_upgrade('upgrade','<?php echo $actId;?>')">
</center>
<div style='height:30px;'></div>
