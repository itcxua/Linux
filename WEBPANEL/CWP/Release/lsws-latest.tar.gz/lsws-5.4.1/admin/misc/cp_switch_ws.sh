#!/bin/sh

##############################################################################
# Switch between Apache and LiteSpeed Web Server under control panel environment
# @Author:   LiteSpeed Technologies, Inc. (https://www.litespeedtech.com)
# @Copyright: (c) 2016
##############################################################################

check_errs()
{
  if [ "${1}" -ne "0" ] ; then
    echo "[ERROR] ${2}" 
    exit ${1}
  fi
}

INST_USER=`id`
INST_UID=`expr "$INST_USER" : 'uid=\(.*\)(.*) gid=.*'`
INST_USER=`expr "$INST_USER" : 'uid=.*(\(.*\)) gid=.*'`
if [ $INST_UID != "0" ]; then
    check_errs 1 "Only root user can switch web server!"
fi

display_usage()
{
    cat <<EOF
cp_switch_ws.sh - Switch between Apache and LiteSpeed under control panel environments.
Currently supported control panels are cPanel, Plesk, DirectAdmin, and CentOS Web Panel.
LiteSpeed plugin is required to be installed prior for cPanel and Plesk detection.
CustomBuild 2.0 is required to be installed prior for DirectAdmin detection.

Usage: cp_switch_ws.sh apache|lsws
Param: targeted web server. Fixed value either "apache" or "lsws"

EOF
    exit 1
}


detect_control_panel()
{
    # detect cPanel
    if [ -d "/usr/local/cpanel/whostmgr" ] ; then
        CP="WHM"
        CPCMD="/usr/local/cpanel/whostmgr/docroot/cgi/lsws/bin/lsws_cmd.sh"
        if [ -f "$CPCMD" ] ; then
            echo "Detected cPanel WHM Environment"
        else
            check_errs 1 "cPanel environment detected, but LiteSpeed WHM plugin not installed."
        fi
    # detect Plesk
    elif [ -e "/opt/psa/version" ] || [ -e "/usr/local/psa/version" ] ; then
        CP="PSA"
        if [ -e "/usr/local/psa/version" ] ; then
            PSA_BASE="/usr/local/psa"
        else
            PSA_BASE="/opt/psa"
        fi

        CPCMD="$PSA_BASE/admin/sbin/modules/litespeed/lsws_cmd"
        if [ -f "$CPCMD" ] ; then
            echo "Detected Plesk Environment"
        else
            check_errs 1 "Plesk environment detected, but LiteSpeed Plesk plugin not installed."
        fi
    # detect DirectAdmin
    elif [ -d "/usr/local/directadmin" ] ; then
        CP="DA"
        DA_DIR="/usr/local/directadmin/custombuild"

        if [[ `/usr/local/directadmin/custombuild/build version` =~ ^2* ]] ; then
            echo "Detected DirectAdmin Environment"
        else
            check_errs 1 "DirectAdmin environment detected, but CustomBuild 2.0 not available"
        fi
    # detect CentOS Web Panel
    elif [ -d "/usr/local/cwpsrv" ] ; then
        CP="CWP"
        echo "Detected CentOS Web Panel Environment"
    else
        check_errs 1 "Cannot detect control panel environment. Only cPanel WHM, Plesk, DirectAdmin are checked for now."
    fi
}


switch_cp()
{
    if [ "x$1" = "xapache" ] ; then
        # param value SWITCH_TO_APACHE is hard-coded in plugin
        pkill wswatch.sh
        stop_running_ws
        $CPCMD $LSWSHOME "SWITCH_TO_APACHE"
    elif [ "x$1" = "xlsws" ] ; then
        # param value SWITCH_TO_LSWS is hard-coded in plugin
        $CPCMD $LSWSHOME "SWITCH_TO_LSWS"
    fi
}


switch_da()
{
    cd ${DA_DIR}

    pmod1=`grep "php1_mode" /usr/local/directadmin/custombuild/options.conf | cut -d = -f 2 | xargs`
    pmod2=`grep "php2_mode" /usr/local/directadmin/custombuild/options.conf | cut -d = -f 2 | xargs`

    if [ "x$1" = "xapache" ] ; then
        pkill wswatch.sh
        DAWS=apache
        if [ "x$pmod1" = "xlsphp" ] ; then
            ./build set php1_mode fastcgi
            ./build set mod_ruid2 no
            ./build php n
            ./build rewrite_confs
        fi
    else
        DAWS=litespeed
        if [ "x$pmod1" != "xlsphp" ] ; then
            ./build set php1_mode lsphp
            if [ "x$pmod2" != "xlsphp" ] ; then
                ./build set php2_mode lsphp
            fi
            ./build php n
            ./build rewrite_confs
        fi
    fi

    ./build set webserver $DAWS
    ./build $DAWS
}


switch_cwp() 
{
    if [ "x$1" = "xapache" ] ; then
        pkill wswatch.sh
        stop_running_ws
        echo "Starting Apache..."
        if [ -e "/usr/local/apache/bin/httpd_ls_bak" ] ; then
            mv /usr/local/apache/bin/httpd_ls_bak /usr/local/apache/bin/httpd
        fi
        service_manager "start" "httpd"
        echo "Apache has been started successfully."
    elif [ "x$1" = "xlsws" ] ; then
        stop_running_ws
        echo "Starting LiteSpeed Enterprise..."
        service_manager "start" "lsws"
        echo "LiteSpeed Enterprise has been started successfully."
    fi
}


service_manager() 
{
    if [ -d "/usr/lib/systemd" ] ; then
        /usr/bin/systemctl "$1" "$2" > /dev/null 2>&1
    else
        /sbin/service "$2" "$1" > /dev/null 2>&1
    fi
}


stop_running_ws()
{
    local AP_PIDFILE=/usr/local/apache/logs/httpd.pid
    local LSWS_PIDFILE=/tmp/lshttpd/lshttpd.pid

    if [ -e "$AP_PIDFILE" ] ; then
        local AP_PID=$(cat $AP_PIDFILE)
    fi
    if [ -e "$LSWS_PIDFILE" ] ; then
        local LSWS_PID=$(cat $LSWS_PIDFILE)
    fi

    if [ -e "$LSWS_PIDFILE" ] && [ "$(ps -ef | grep -w 'lshttpd\|litespeed' | grep -v grep | grep -w $LSWS_PID)" != "" ] || [ "$(ps -ef | grep -w 'lshttpd\|litespeed' | grep -v grep)" != "" ] ; then
        echo "Stopping LiteSpeed Enterprise..."
        service_manager "stop" "lsws"
        sleep 1

        RETRY=30
        CHECK=$(ps -ef | grep -w 'lshttpd\|litespeed' | grep -v grep)

        while [ "$RETRY" -gt 0 ] && [ "$CHECK" != "" ] ; do
            ((RETRY--))
            sleep 1
            CHECK=$(ps -ef | grep -w 'lshttpd\|litespeed' | grep -v grep)
        done

        pkill -9 lsphp > /dev/null 2>&1

        if [ "$CHECK" != "" ] ; then
            pkill -9 litespeed > /dev/null 2>&1
            pkill -9 lshttpd > /dev/null 2>&1
            pkill -9 lscgid > /dev/null 2>&1
            sleep 1
        fi

        if [ "$(ps -ef | grep -w 'lshttpd\|litespeed' | grep -v grep)" != "" ] ; then
            echo "LiteSpeed Enterprise could not be stopped."
            exit 1
        else
            echo "LiteSpeed Enterprise has been stopped successfully."
        fi
    fi

    if [ -e "$AP_PIDFILE" ] && [ "$(ps -ef | grep -w $AP_PID | grep httpd | grep -v grep | grep -v lscgid)" != "" ] || [ "$(ps -ef | grep httpd | grep -v grep | grep -v lscgid)" != "" ] ; then
        echo "Stopping Apache..."
        service_manager "stop" "httpd"
        sleep 1

        RETRY=30
        CHECK=$(ps -ef | grep httpd | grep -v grep | grep -v lscgid)

        while [ "$RETRY" -gt 0 ] && [ "$CHECK" != "" ] ; do
            ((RETRY--))
            sleep 1
            CHECK=$(ps -ef | grep httpd | grep -v grep | grep -v lscgid)
        done

        if [ "$CHECK" != "" ] ; then
            pkill -9 httpd > /dev/null 2>&1
            sleep 1
        fi

        if [ "$(ps -ef | grep httpd | grep -v grep | grep -v lscgid)" != "" ] ; then
            echo "Apache could not be stopped."
            exit 1
        else
            echo "Apache killed successfully."
        fi
    fi
}


if [ $# -ne 1 ] ; then
    echo "Illegal parameters = $# !"
    display_usage
fi

# set LSWSHOME
cd `dirname "$0"`
CURDIR=`pwd`
LSWSHOME=`dirname $CURDIR`
LSWSHOME=`dirname $LSWSHOME`

if [ "x$1" != "xapache" ] && [ "x$1" != "xlsws" ] ; then
    display_usage
fi

detect_control_panel

if [ "$CP" = "WHM" ] || [ "$CP" = "PSA" ] ; then
    switch_cp $1
elif [ "$CP" = "DA" ] ; then
    switch_da $1
elif [ "$CP" = "CWP" ] ; then
    switch_cwp $1
fi
