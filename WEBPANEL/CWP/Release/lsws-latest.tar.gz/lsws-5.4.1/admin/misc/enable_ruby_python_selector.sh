#!/bin/sh

WSGI_LSAPI_VER=1.4
if [ -d /opt/alt/ruby18/ ]; then
    echo "Install ruby-lsapi rack gem for ruby 1.8"
    yum install -y alt-ruby18-rubygem-lsapi alt-ruby18-rubygem-rack
fi

if [ -d /opt/alt/ruby19/ ]; then
    echo "Install ruby-lsapi rack gem for ruby 1.9"
    yum install -y alt-ruby19-rubygem-lsapi alt-ruby19-rubygem-rack
fi

if [ -d /opt/alt/ruby20/ ]; then
    echo "Install ruby-lsapi rack gem for ruby 2.0"
    yum install -y alt-ruby20-rubygem-lsapi alt-ruby20-rubygem-rack
fi

if [ -d /opt/alt/ruby21/ ]; then
    echo "Install ruby-lsapi rack gem for ruby 2.1"
    yum install -y alt-ruby21-rubygem-lsapi alt-ruby21-rubygem-rack
fi

if [ -d /opt/alt/ruby22/ ]; then
    echo "Install ruby-lsapi rack gem for ruby 2.2"
    yum install -y alt-ruby22-rubygem-lsapi alt-ruby22-rubygem-rack
fi

if [ -d /opt/alt/ruby23/ ]; then
    echo "Install ruby-lsapi rack gem for ruby 2.3"
    yum install -y alt-ruby23-rubygem-lsapi alt-ruby23-rubygem-rack
fi

if [ -d /opt/alt/ruby24/ ]; then
    echo "Install ruby-lsapi rack gem for ruby 2.4"
    yum install -y alt-ruby24-rubygem-lsapi alt-ruby24-rubygem-rack
fi

if [ -d /opt/alt/ruby25/ ]; then
    echo "Install ruby-lsapi rack gem for ruby 2.5"
    yum install -y alt-ruby25-rubygem-lsapi alt-ruby25-rubygem-rack
fi

if [ -d /opt/alt/ruby26/ ]; then
    echo "Install ruby-lsapi rack gem for ruby 2.6"
    yum install -y alt-ruby26-rubygem-lsapi alt-ruby26-rubygem-rack
fi

if [ -d /opt/plesk/ruby ]; then
    yum install -y gcc gmp-devel
    cd /opt/plesk/ruby
    if [ -d 1.9.3 ]; then
        echo "Install ruby-lsapi gem for ruby 1.9"
        1.9.3/bin/gem install ruby-lsapi
        1.9.3/bin/gem install rack -v=1.6.4
    fi
    if [ -d 2.0.0 ]; then
        echo "Install ruby-lsapi gem for ruby 2.0"
        2.0.0/bin/gem install ruby-lsapi
        2.0.0/bin/gem install rack -v=1.6.4
    fi
    if [ -d 2.1.10 ]; then
        echo "Install ruby-lsapi gem for ruby 2.1"
        2.1.10/bin/gem install ruby-lsapi
        2.1.10/bin/gem install rack -v=1.6.4
    fi
    if [ -d 2.2.10 ]; then
        echo "Install ruby-lsapi gem for ruby 2.2"
        2.2.10/bin/gem install ruby-lsapi
        2.2.10/bin/gem install rack
    fi
    if [ -d 2.3.7 ]; then
        echo "Install ruby-lsapi gem for ruby 2.3"
        2.3.7/bin/gem install ruby-lsapi
        2.3.7/bin/gem install rack
    fi
    if [ -d 2.4.4 ]; then
        echo "Install ruby-lsapi gem for ruby 2.4"
        2.4.4/bin/gem install ruby-lsapi
        2.4.4/bin/gem install rack
    fi
fi

rm wsgi-lsapi-$WSGI_LSAPI_VER.tgz
rm -rf wsgi-lsapi-$WSGI_LSAPI_VER

wget http://www.litespeedtech.com/packages/lsapi/wsgi-lsapi-$WSGI_LSAPI_VER.tgz

tar xvfz wsgi-lsapi-$WSGI_LSAPI_VER.tgz
cd wsgi-lsapi-$WSGI_LSAPI_VER

if [ -d /opt/alt/python27 ]; then
    echo "Install wsgi-lsapi for python 2.7"
    yum install -y alt-python27-wsgi-lsapi
#     /opt/alt/python27/bin/python configure.py
#     make 1>/dev/null 2>&1
#     cp lswsgi /opt/alt/python27/bin/
#     make clean
fi

if [ -d /opt/alt/python33 ]; then
    echo "Install wsgi-lsapi for python 3.3"
    yum install -y alt-python33-wsgi-lsapi
fi

if [ -d /opt/alt/python34 ]; then
    echo "Install wsgi-lsapi for python 3.4"
    yum install -y alt-python34-wsgi-lsapi
fi

if [ -d /opt/alt/python35 ]; then
    echo "Install wsgi-lsapi for python 3.5"
    yum install -y alt-python35-wsgi-lsapi
fi

if [ -d /opt/alt/python36 ]; then
    echo "Install wsgi-lsapi for python 3.6"
    yum install -y alt-python36-wsgi-lsapi
fi


if [ -d /opt/alt/python37 ]; then
    echo "Install wsgi-lsapi for python 3.7"
    yum install -y alt-python37-wsgi-lsapi
fi

if [ -d /opt/cpanel/ea-ruby24/ ]; then
    echo "Install ruby-lsapi for ea-ruby24"
    scl enable ea-ruby24 'gem install ruby-lsapi rack'
    
    if [ ! -f /usr/local/lsws/fcgi-bin/ea-ruby24 ]; then
        cat >/usr/local/lsws/fcgi-bin/ea-ruby24 <<EOF
#!/bin/sh
. /opt/cpanel/ea-ruby24/enable
/opt/cpanel/ea-ruby24/root/usr/bin/ruby \$@

EOF
        chmod a+x /usr/local/lsws/fcgi-bin/ea-ruby24
    fi
    
fi

