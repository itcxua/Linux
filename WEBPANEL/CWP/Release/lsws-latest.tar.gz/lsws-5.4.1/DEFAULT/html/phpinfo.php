<HTML>
<BODY>
   <?php phpinfo() ?>
</BODY>
</HTML>
