#!/bin/sh
# SCRIPT: install.sh
# PURPOSE: Install LS Web Cache Manager cPanel Plugin
# AUTHOR: LiteSpeed Technologies
#

PLUGIN_DIR='/usr/local/cpanel/base/frontend/paper_lantern/ls_web_cache_manager'
PERL_MODULE_DIR='/usr/local/cpanel/Cpanel/API'
API_DIR='/usr/local/cpanel/bin/admin/Lsws'

pushd `dirname "$0"` > /dev/null

echo 'Installing LS Web Cache Manager...'
echo ""

# checks for existing plugin folder and	deletes	if exists
if [ -d $PLUGIN_DIR ]
then
    rm -rf $PLUGIN_DIR
fi

# Create the directory for the plugin
mkdir -p $PLUGIN_DIR

# Move all files to plugin directory
cp -r * ${PLUGIN_DIR}/

chmod -R 644 $PLUGIN_DIR
find ${PLUGIN_DIR}/ -type d -execdir chmod 755 {} +
chmod 700 ${PLUGIN_DIR}/*.sh

#Move interface file to paper_lantern directory.
mv -f ${PLUGIN_DIR}/ls_web_cache_manager.html.tt ${PLUGIN_DIR}/..

echo 'Installing needed Perl module and custom API calls...'
echo ""

cp -f ../lsws.pm ${PERL_MODULE_DIR}/

if [ ! -d $API_DIR ] ; then
    mkdir $API_DIR
fi

cp -f ../lswsAdminBin* ${API_DIR}/

chmod 700 ${API_DIR}/lswsAdminBin
chmod 644 ${API_DIR}/lswsAdminBin.conf
chmod 644 ${PERL_MODULE_DIR}/lsws.pm

# Install the plugin (which also places the png image in the proper location)
/usr/local/cpanel/scripts/install_plugin ${PLUGIN_DIR}/ls_web_cache_manager.tar.gz

echo 'Installation for  LS Web Cache Manager Completed!'
echo ""

popd > /dev/null
