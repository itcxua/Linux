#!/bin/sh

cd `dirname "$0"`

/usr/local/bin/php -c ./php.ini ./cmd_buildmatchingphp.php $1

if [ -f "/etc/cagefs/cagefs.mp" ] ; then
# cagefs installed first, need update mount point
    cagefsctl --update
fi
