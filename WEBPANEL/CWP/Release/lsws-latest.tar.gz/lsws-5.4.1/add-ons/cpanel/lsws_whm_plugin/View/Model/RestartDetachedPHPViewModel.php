<?php

/* * ******************************************
 * LiteSpeed Web Server Plugin for WHM
 * @author: LiteSpeed Technologies, Inc. (https://www.litespeedtech.com)
 * @copyright: (c) 2018-2019
 * ******************************************* */

namespace LsPanel\View\Model;

use \Lsc\Wp\Context\Context;
use \Lsc\Wp\Logger;
use \Lsc\Wp\LSCMException;

class RestartDetachedPHPViewModel
{

    const STEP_CONFIRM = 0;
    const STEP_DO_ACTION = 1;

    const FLD_ICON_DIR = 'iconDir';

    /**
     * @var int
     */
    private $step;

    /**
     * @var string
     */
    private $iconDir;

    /**
     *
     * @param int  $step
     */
    public function __construct( $step )
    {
        $this->step = $step;

        $this->init();
    }

    private function init()
    {
        $this->setIconDir();
    }

    /**
     *
     * @param string  $field
     * @return null|string
     */
    public function getTplData( $field )
    {
        switch ( $field ) {
            case self::FLD_ICON_DIR:
                return $this->iconDir;
            default:
                return null;
        }
    }

    private function setIconDir()
    {
        $iconDir = '';

        try
        {
            $iconDir = Context::getOption()->getIconDir();
        }
        catch ( LSCMException $e )
        {
            Logger::debug($e->getMessage() . ' Could not get icon directory.');
        }

        $this->iconDir = $iconDir;
    }

    /**
     *
     * @return string
     */
    public function getTpl()
    {
        if ( $this->step == self::STEP_DO_ACTION) {
            return realpath(__DIR__ . '/../Tpl') . '/RestartDetachedPHP.tpl';
        }

        return realpath(__DIR__ . '/../Tpl') . '/RestartDetachedPHPConfirm.tpl';
    }

}
