<?php

/* * ******************************************
 * LiteSpeed Web Cache Manager Plugin for cPanel
 * @Author: LiteSpeed Technologies, Inc. (https://www.litespeedtech.com)
 * @Copyright: (c) 2018
 * ******************************************* */

use \LsUserPanel\PluginSettings;

require_once 'autoloader.php';

/**
 *
 * @return string
 */
function getCustomLandingTheme()
{
    $custTheme = '';

    $useCustTheme =
            PluginSettings::getSetting(PluginSettings::FLD_USE_CUST_THEME);

    if ( $useCustTheme ) {
        $custTheme = PluginSettings::getSetting(PluginSettings::FLD_CUST_THEME);
    }

    return $custTheme;
}

PluginSettings::initialize();

$customLandingTheme = getCustomLandingTheme();

if ( $customLandingTheme != '' && is_dir("landing/{$customLandingTheme}") ) {
    $activeTheme = $customLandingTheme;
}
else {
    $activeTheme = 'default';
}

include "landing/{$activeTheme}/index.php";
