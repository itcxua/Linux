<?php

/* * ******************************************
 * LiteSpeed Web Server Plugin for WHM
 * @Author: Lite Speed Technologies, Inc. (https://www.litespeedtech.com)
 * @Copyright: (c) 2013-2019
 * ******************************************* */

use \Lsc\Wp\Logger;
use \Lsc\Wp\LSCMException;
use \LsPanel\WhmMod_LiteSpeed_ControlApp;

/**
 *
 * @return int
 */
function checkacl()
{
    $user = $_ENV['REMOTE_USER'];

    if ( $user == 'root' ) {
        return 1;
    }

    $reseller = file_get_contents('/var/cpanel/resellers');

    foreach ( explode("\n", $reseller) as $line ) {

        if ( preg_match("/^{$user}:/", $line) ) {
            $line = preg_replace("/^{$user}:/", '', $line);

            foreach ( explode(',', $line) as $perm ) {

                if ( $perm == 'all' ) {
                    return 1;
                }
            }
        }
    }

    return 0;
}

if ( checkacl($acl) == 0 ) {
    header("status: 403\n");
    echo '<h1>Only root privileged users can access this module!</h1>';
}
else {
    require_once 'autoloader.php';

    try
    {
        $app = new WhmMod_LiteSpeed_ControlApp;
        $app->Run();
    }
    catch ( LSCMException $e )
    {
        $msg = $e->getMessage();
        Logger::error($msg);

        header("status: 500\n");
        echo "<h1>{$msg}</h1>";
    }
}
