<?php

/* * *********************************************
 * LiteSpeed Web Cache Management Plugin for cPanel
 * @Author: LiteSpeed Technologies, Inc. (https://www.litespeedtech.com)
 * @Copyright: (c) 2018-2019
 * *******************************************
 */

namespace LsUserPanel\Lsc;

use \LsUserPanel\CPanelWrapper;
use \LsUserPanel\Lsc\Context\UserContext;
use \LsUserPanel\Lsc\Panel\UserControlPanel;
use \LsUserPanel\Lsc\UserLogger;
use \LsUserPanel\Lsc\UserLSCMException;
use \LsUserPanel\Lsc\UserLscwpPlugin;
use \LsUserPanel\Lsc\UserUserCommand;
use \LsUserPanel\Lsc\UserWPInstall;
use \LsUserPanel\PluginSettings;

/**
 * Running as user - suexec
 */
class UserUserCommand
{

    const EXIT_ERROR = 1;
    const EXIT_SUCC = 2;
    const EXIT_FAIL = 4;
    const EXIT_INCR_SUCC = 8;
    const EXIT_INCR_FAIL = 16;
    const EXIT_TIMEOUT = 124;
    const CMD_STATUS = 'status';
    const CMD_DIRECT_ENABLE = 'direct_enable';
    const CMD_DISABLE = 'disable';
    const CMD_UPDATE_TRANSLATION = 'update_translation';
    const CMD_REMOVE_LSCWP_PLUGIN_FILES = 'remove_lscwp_plugin_files';

    private function __construct(){}

    /**
     * Handles logging unexpected error output (or not if too long) and returns
     * a crafted message to be displayed instead.
     *
     * @param UserWPInstall  $wpInstall  WordPress Installation object.
     * @param string         $err        Complied error message.
     * @param int            $lines      Number of $output lines read into the
     *                                    error msg.
     * @return string                    Message to be displayed instead.
     */
    private static function handleUnexpectedError($wpInstall, &$err, $lines )
    {
        $msg = 'Unexpected Error Encountered!';
        $path = $wpInstall->getPath();

        /**
        * $lines > 500 are likely some custom code triggering a page render.
         * Throw out actual message in this case.
        */
        if ( $lines < 500 ) {
            $commonErrs = array(
                UserWPInstall::ST_ERR_EXECMD_DB =>
                    _('Error establishing a database connection.')
            );

            foreach ( $commonErrs as $statusBit => $commonErr ) {

                if ( strpos($err, $commonErr) !== false ) {
                    $wpInstall->unsetStatusBit(UserWPInstall::ST_ERR_EXECMD);
                    $wpInstall->setStatusBit($statusBit);

                    $msg .= " {$commonErr}";
                    $match = true;
                    break;
                }
            }

            if ( !$match ) {
                UserLogger::logMsg( "{$path} - {$err}", UserLogger::L_ERROR);
                return "{$msg} " . _('See ls_webcachemgr.log for more information.');
            }
        }

        UserLogger::logMsg( "{$path} - {$msg}", UserLogger::L_ERROR);
        return $msg;
    }

    /**
     *
     * @param string         $action
     * @param UserWPInstall  $wpInstall
     * @param mixed[]        $extraArgs
     * @return string
     */
    private static function  getIssueCmd( $action, UserWPInstall $wpInstall,
            $extraArgs = array() )
    {
        $timeout = UserControlPanel::PHP_TIMEOUT;
        $phpBin = $wpInstall->getPhpBinary();
        $path = $wpInstall->getPath();
        $serverName = $wpInstall->getData(UserWPInstall::FLD_SERVERNAME);
        $env = UserContext::getOption()->getInvokerName();

        if ( $serverName === null ) {
            $serverName = $docRoot = 'x';
        }
        else {
            $docRoot = $wpInstall->getData(UserWPInstall::FLD_DOCROOT);

            if ( $docRoot === null ) {
                $docRoot = 'x';
            }
        }

        $modifier = implode(' ', $extraArgs);

        $lswsHome =
                PluginSettings::getSetting(PluginSettings::FLD_LSWS_HOME_DIR);
        $file = "{$lswsHome}/add-ons/webcachemgr/src/UserCommand.php";

        $cmd = "cd {$path}/wp-admin && timeout {$timeout} {$phpBin} {$file} "
                . "{$action} {$path} {$docRoot} {$serverName} {$env}"
                . (($modifier !== '') ? " {$modifier}" : '');

        return $cmd;
    }

    /**
     *
     * @param string         $action
     * @param UserWPInstall  $wpInstall
     * @param string[]       $extraArgs
     * @return boolean
     */
    public static function issue( $action, UserWPInstall $wpInstall,
            $extraArgs = array() )
    {
        if ( !self::preIssueValidation($action, $wpInstall, $extraArgs) ) {
            return false;
        }

        $cmd = self::getIssueCmd($action, $wpInstall, $extraArgs);

        $cpanel = CPanelWrapper::getCpanelObj();

        $result = $cpanel->uapi('lsws', 'execIssueCmd', array( 'cmd' => $cmd ));

        $return_var = $result['cpanelresult']['result']['data']['retVar'];
        $resOutput = $result['cpanelresult']['result']['data']['output'];

        $output = (!empty($resOutput)) ? explode("\n", $resOutput) : array();

        UserLogger::debug(
                "Issue command {$action}={$return_var} {$wpInstall}\n{$cmd}");
        UserLogger::debug('output = ' . var_export($output, true));

        $path = $wpInstall->getPath();

        if ( $wpInstall->hasNewLscwpFlagFile() ) {
            $subAction = self::CMD_REMOVE_LSCWP_PLUGIN_FILES;
            $subCmd = self::getIssueCmd($subAction, $wpInstall);

            $result = $cpanel->uapi('lsws', 'execIssueCmd',
                    array( 'cmd' => $subCmd ));

            $subReturn_var = $result['cpanelresult']['result']['data']['retVar'];
            $subResOutput = $result['cpanelresult']['result']['data']['output'];

            if ( !empty($subResOutput) ) {
                $subOutput = explode("\n", $subResOutput);
            }
            else {
                $subOutput = array();
            }

            UserLogger::debug("Issue command {$subAction}={$subReturn_var} "
                    . "{$wpInstall}\n{$subCmd}");
            UserLogger::debug('output = ' . var_export($subOutput, true));

            $wpInstall->removeNewLscwpFlagFile();
        }

        $newStatus = $retStatus = $cmdStatus = 0;

        switch ($return_var) {
            case UserUserCommand::EXIT_TIMEOUT:
                $newStatus |= UserWPInstall::ST_ERR_TIMEOUT;
                break;
            case UserUserCommand::EXIT_ERROR:
            case 255:
                $newStatus |= UserWPInstall::ST_ERR_EXECMD;
                break;
            //no default
        }

        $expectedOutput = false;
        $unexpectedLines = 0;
        $debug = $succ = $upgrade =  $err = $msg = '';
        $curr = &$err;

        foreach ( $output as $line ) {

            /**
             * If this line is not present in output, did not return normally.
             * This line will appear after any [UPGRADE] output.
             */
            if ( strpos($line, 'LS UserCommand Output Start') !== false ) {
                $expectedOutput = true;
            }
            elseif ( strpos($line, '[RESULT]') !== false ) {

                if ( preg_match('/SITEURL=(.+)/', $line, $m) ) {

                    if ( !$wpInstall->setSiteUrl($m[1]) ) {
                        /**
                         * Matching docroot could not be found, ignore other
                         * output. setCmdStatusAndMsg() etc already handled in
                         * setSiteUrl().
                         */
                        return;
                    }
                }
                elseif ( preg_match('/STATUS=(.+)/', $line, $m) ) {
                    $retStatus |= (int)$m[1];
                }
                elseif ( preg_match('/GET_TRANSLATION=(.+)/', $line, $m) ) {
                    $translationInfo = explode(' ', $m[1]);
                    $locale = $translationInfo[0];
                    $lscwpVer = $translationInfo[1];

                    if ( UserLscwpPlugin::retrieveTranslation($locale,
                            $lscwpVer) ) {

                        $subAction = self::CMD_UPDATE_TRANSLATION;
                        $subCmd = self::getIssueCmd($subAction, $wpInstall);

                        $result = $cpanel->uapi('lsws', 'execIssueCmd',
                                array( 'cmd' => $subCmd ));

                        $subReturn_var = $result['cpanelresult']['result']['data']['retVar'];
                        $subResOutput = $result['cpanelresult']['result']['data']['output'];

                        if ( !empty($subResOutput) ) {
                            $subOutput = explode("\n", $subResOutput);
                        }
                        else {
                            $subOutput = array();
                        }

                        UserLogger::debug("Issue command {$subAction}="
                                . "{$subReturn_var} {$wpInstall}\n{$subCmd}");
                        UserLogger::debug('output = '
                                . var_export($subOutput, true));

                        foreach ( $subOutput as $subLine ) {

                            if ( preg_match('/BAD_TRANSLATION=(.+)/', $subLine,
                                    $m2) ) {

                                $translationInfo = explode(' ', $m2[1]);
                                $locale = $translationInfo[0];
                                $lscwpVer = $translationInfo[1];

                                UserLscwpPlugin::removeTranslationZip($locale,
                                        $lscwpVer);
                            }
                        }
                    }
                }
                else {
                    $err .= "Unexpected result line {$line}\n";
                }
            }
            elseif ( ($pos = strpos($line, '[DEBUG]')) !== false ) {
                $debug .= substr($line, $pos + 7) . "\n";
                $curr = &$debug;
            }
            elseif ( $pos = (strpos($line, '[SUCCESS]')) !== false ) {
                $succ .= substr($line, $pos + 9) . "\n";
                $curr = &$succ;
            }
            elseif ( ($pos = strpos($line, '[ERROR]')) !== false ) {
                $err .= substr($line, $pos + 7) . "\n";
                $curr = &$err;
            }
            elseif ( strpos($line, '[UPGRADE]') !== false ) {
                //Ignore this output
                $curr = &$upgrade;
            }
            else {

                if ( !$expectedOutput ) {
                    $line = htmlentities($line);
                    $unexpectedLines++;
                }

                $curr .= "{$line}\n";
            }
        }

        if ( $newStatus == 0 && !$expectedOutput ) {
            $newStatus |= UserWPInstall::ST_ERR_EXECMD;
        }

        if ( $newStatus != 0 ) {
            $cmdStatus |= UserUserCommand::EXIT_INCR_FAIL;

            $wpInstall->addUserFlagFile(false);
            $newStatus |= UserWPInstall::ST_FLAGGED;
        }

        if ( ($newStatus |= $retStatus) != 0 ) {
            $wpInstall->updateCommandStatus($newStatus);
        }

        if ( $debug ) {
            UserLogger::logMsg("{$path} - {$debug}", UserLogger::L_DEBUG);
        }

        if ( $succ ) {
            $cmdStatus |= UserUserCommand::EXIT_SUCC;
            $msg = $succ;
        }

        if ( $err ) {

            if ( $return_var == UserUserCommand::EXIT_FAIL ) {
                $cmdStatus |= UserUserCommand::EXIT_FAIL;
            }
            else {
                $cmdStatus |= UserUserCommand::EXIT_ERROR;
            }

            if ( $expectedOutput ) {
                $msg = $err;
                UserLogger::logMsg("{$path} - {$err}", UserLogger::L_ERROR);
            }
            else {
                $msg = self::handleUnexpectedError($wpInstall, $err,
                        $unexpectedLines);
            }
        }

        $wpInstall->setCmdStatusAndMsg($cmdStatus, $msg);

        return true;
    }

    /**
     *
     * @param string         $action
     * @param UserWPInstall  $wpInstall
     * @param string[]       $extraArgs  Not used at the moment.
     * @return boolean
     * @throws UserLSCMException
     */
    private static function preIssueValidation( $action,
            UserWPInstall $wpInstall, $extraArgs )
    {
        if ( !self::isSupportedCmd($action) ) {
            throw new UserLSCMException("Illegal action {$action}.",
                    UserLSCMException::E_PROGRAM);
        }

        if ( !$wpInstall->hasValidPath() ) {
            return false;
        }

        return true;
    }

    /**
     *
     * @param string  $action
     * @return boolean
     */
    private static function isSupportedCmd( $action )
    {
        $supported = array(
            self::CMD_STATUS,
            self::CMD_DIRECT_ENABLE,
            self::CMD_DISABLE,
        );

        return in_array($action, $supported);
    }

}
