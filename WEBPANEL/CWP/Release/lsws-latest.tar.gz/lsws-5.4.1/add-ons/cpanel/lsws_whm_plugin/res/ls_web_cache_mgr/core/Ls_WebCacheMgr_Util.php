<?php

/* * ******************************************
 * LiteSpeed Web Cache Management Plugin for cPanel
 * @Author: LiteSpeed Technologies, Inc. (https://www.litespeedtech.com)
 * @Copyright: (c) 2018-2019
 * ******************************************* */

namespace LsUserPanel;

use \LsUserPanel\Lsc\UserLSCMException;
use \LsUserPanel\Lsc\UserLogger;

class Ls_WebCacheMgr_Util
{

    /**
     * @var null|string
     */
    private static $homeDir;

    private function __construct() {}

    /**
     *
     * @return string
     * @throws UserLSCMException
     */
    public static function getHomeDir()
    {
        if ( !self::$homeDir ) {

            if ( isset($_SERVER['HOME']) ) {
                self::$homeDir = $_SERVER['HOME'];
            }
            elseif ( isset($_SERVER['DOCUMENT_ROOT']) ) {
                self::$homeDir = $_SERVER['DOCUMENT_ROOT'];
            }
            else {
                throw new UserLSCMException('Could not get home directory');
            }
        }

        return self::$homeDir;
    }

    /**
     * Returns the length of chars that make up the users the home dir.
     *
     * @return int
     */
    public static function getHomeDirLen()
    {
        $homeDirLen = strlen(self::getHomeDir());

        return $homeDirLen;
    }

    /**
     * Gets currently executing user through cPanel set $_ENV variable.
     *
     * @return string
     */
    public static function getCurrentCpanelUser()
    {
        return $_ENV['USER'];
    }

    /**
     *
     * @param string  $tag
     * @return null|string
     */
    public static function get_request_var( $tag )
    {
        if ( !isset($_REQUEST[$tag]) ) {
            return NULL;
        }

        return trim($_REQUEST[$tag]);
    }

    /**
     *
     * @param string  $tag
     * @return null|string[]
     */
    public static function get_request_list( $tag )
    {
        if ( !isset($_REQUEST[$tag]) ) {
            return NULL;
        }

        $result = $_REQUEST[$tag];

        return (is_array($result)) ? $result : NULL;
    }

    /**
     * Touches a flag file to inform LiteSpeed Web Server to restart user owned
     * running detached PHP processes the next time the server uses that PHP
     * handler.
     */
    public static function restartDetachedPHP()
    {
        $homeDir = self::getHomeDir();

        $restartPHPFlagFile = $homeDir . '/.lsphp_restart.txt';

        if ( touch($restartPHPFlagFile) ) {
            UserLogger::addUiMsg(
                    _('LiteSpeed Web Server notified to restart detached PHP processes.'),
                    UserLogger::UI_SUCC);
        }
        else {
            UserLogger::addUiMsg(
                    _('Could not notify LiteSpeed Web Server to restart detached PHP processes.'),
                    UserLogger::UI_ERR);
        }
    }

    /**
     * Recursively deletes a directory and its contents.
     *
     * @param string  $dir  Directory path
     */
    public static function rrmdir( $dir, $keepParent = false )
    {
        if ( $dir != '' && is_dir($dir) ) {

            foreach ( glob($dir . '/*') as $file ) {

                if ( is_dir($file) ) {
                    self::rrmdir($file);
                }
                else {
                    unlink($file);
                }
            }

            if ( !$keepParent )
                rmdir($dir);

            return true;
        }

        return false;
    }

    /**
     *
     * @param mixed[]  $ajaxInfo
     */
    public static function ajaxReturn( $ajaxInfo )
    {
        echo json_encode($ajaxInfo);
        exit;
    }

    public static function setTextDomain()
    {
        $activeLocaleDir = '';

        $cpanel = CPanelWrapper::getCpanelObj();
        $attributes = $cpanel->uapi('Locale', 'get_attributes');
        $locale = $attributes['cpanelresult']['result']['data']['locale'];

        $langDir = realpath(__DIR__ . '/../lang');
        $localeDir = "{$langDir}/{$locale}";
        $custLocaleDir = "{$langDir}/cust/{$locale}";

        if ( file_exists($custLocaleDir) ) {
            $activeLocaleDir = $custLocaleDir;
        }
        elseif ( file_exists($localeDir) ) {
            $activeLocaleDir = $localeDir;
        }

        if ( $activeLocaleDir != '' ) {
            setlocale(LC_MESSAGES, 'en_US.utf8');
            bindtextdomain('messages', $activeLocaleDir);
            bind_textdomain_codeset('messages', 'UTF8');
            textdomain('messages');
        }
    }

}
