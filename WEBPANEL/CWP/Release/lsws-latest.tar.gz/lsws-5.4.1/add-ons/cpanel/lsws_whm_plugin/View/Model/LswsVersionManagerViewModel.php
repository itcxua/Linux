<?php

/* * ******************************************
 * LiteSpeed Web Server Plugin for WHM
 * @author: LiteSpeed Technologies, Inc. (https://www.litespeedtech.com)
 * @copyright: (c) 2018-2019
 * ******************************************* */

namespace LsPanel\View\Model;

use \LsPanel\WhmMod_LiteSpeed_Util;
use \Lsc\Wp\Context\Context;
use \Lsc\Wp\Logger;
use \Lsc\Wp\LSCMException;

class LswsVersionManagerViewModel
{

    const FLD_ICON_DIR = 'iconDir';
    const FLD_LSWS_VER = 'lswsVer';
    const FLD_LSWS_NEW_VER = 'lswsNewVer';
    const FLD_LSWS_INSTALLED_VERS = 'lswsInstalledVers';
    const FLD_LSWS_CURR_BUILD = 'lswsCurrBuild';
    const FLD_LSWS_NEW_BUILD = 'lswsNewBuild';
    const FLD_ERR_MSGS = 'errMsgs';
    const FLD_SUCC_MSGS = 'succMsgs';

    /**
     * @var WhmMod_LiteSpeed_Util
     */
    private $util;

    /**
     * @var (boolean|string|string[])[]
     */
    private $tplData = array();

    /**
     *
     * @param WhmMod_LiteSpeed_Util  $util
     */
    public function __construct( WhmMod_LiteSpeed_Util $util )
    {
        $this->util = $util;

        $this->init();
    }

    private function init()
    {
        $this->setIconDir();
        $this->setVersionAndBuildData();
        $this->setMsgData();
    }

    /**
     *
     * @param string  $field
     * @return null|boolean|string|string[]
     */
    public function getTplData( $field )
    {
        if ( !isset($this->tplData[$field]) ) {
            return null;
        }

        return $this->tplData[$field];

    }

    private function setIconDir()
    {
        $iconDir = '';

        try
        {
            $iconDir = Context::getOption()->getIconDir();
        }
        catch ( LSCMException $e )
        {
            Logger::debug($e->getMessage() . ' Could not get icon directory.');
        }

        $this->tplData[self::FLD_ICON_DIR] = $iconDir;
    }

    private function setVersionAndBuildData()
    {
        $currBuild = $newBuild = '';

        $verInfo = array();
        $this->util->populateVersionInfo($verInfo);

        if ( isset($verInfo['lsws_build']) ) {
            $currBuild = $verInfo['lsws_build'];
            $newBuild = $verInfo['new_build'];
        }

        $installed = $this->util->GetInstalledVersions();
        natsort($installed);

        $this->tplData[self::FLD_LSWS_VER] = $verInfo['lsws_version'];
        $this->tplData[self::FLD_LSWS_NEW_VER] = $verInfo['new_version'];
        $this->tplData[self::FLD_LSWS_CURR_BUILD] = $currBuild;
        $this->tplData[self::FLD_LSWS_NEW_BUILD] = $newBuild;
        $this->tplData[self::FLD_LSWS_INSTALLED_VERS] =
                array_reverse($installed);
    }

    private function setMsgData()
    {
        $this->tplData[self::FLD_ERR_MSGS] = Logger::getUiMsgs(Logger::UI_ERR);
        $this->tplData[self::FLD_SUCC_MSGS] =
                Logger::getUiMsgs(Logger::UI_SUCC);
    }

    public function getTpl()
    {
        return realpath(__DIR__ . '/../Tpl') . '/LswsVersionManager.tpl';
    }

}
