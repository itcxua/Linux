<?php

/* * ******************************************
 * LiteSpeed Web Cache Management Plugin for cPanel
 * @author: LiteSpeed Technologies, Inc. (https://www.litespeedtech.com)
 * @copyright: (c) 2018
 * ******************************************* */

namespace LsUserPanel\View\Model;

use \LsUserPanel\Ls_WebCacheMgr_Controller;
use \LsUserPanel\Lsc\Context\UserContext;
use \LsUserPanel\Lsc\UserLogger;
use \LsUserPanel\Lsc\UserLSCMException;
use \LsUserPanel\Lsc\UserUtil;

class MainViewModel
{

    const FLD_PLUGIN_VER = 'pluginVer';
    const FLD_VH_CACHE_DIR = 'vhCacheDir';
    const FLD_VH_CACHE_DIR_EXISTS = 'vhCacheDirExists';
    const FLD_ICON_DIR = 'iconDir';
    const FLD_ERR_MSGS = 'errMsgs';
    const FLD_SUCC_MSGS = 'succMsgs';

    /**
     * @var mixed[]
     */
    private $tplData = array();

    public function __construct()
    {
        $this->init();
    }

    private function init()
    {
        $this->setPluginVerData();
        $this->setVhCacheDirData();
        $this->setIconDirData();
        $this->setMsgData();
    }

    /**
     *
     * @param string  $field
     * @return null|mixed
     */
    public function getTplData( $field )
    {
        if ( !isset($this->tplData[$field]) ) {
            return null;
        }

        return $this->tplData[$field];
    }

    private function setPluginVerData()
    {
        $this->tplData[self::FLD_PLUGIN_VER] =
                Ls_WebCacheMgr_Controller::MODULE_VERSION;
    }

    private function setVhCacheDirData()
    {
        $cacheDir = UserUtil::getUserCacheDir();
        $exists = ($cacheDir == '') ? false : file_exists($cacheDir);

        $this->tplData[self::FLD_VH_CACHE_DIR] = $cacheDir;
        $this->tplData[self::FLD_VH_CACHE_DIR_EXISTS] = $exists;
    }

    private function setIconDirData()
    {
        $iconDir = '';

        try {
            $iconDir = UserContext::getOption()->getIconDir();
        }
        catch ( UserLSCMException $e ) {
            $msg = $e->getMessage() . ' Could not get icon directory.';
            UserLogger::logMsg($msg, UserLogger::L_DEBUG);
        }

        $this->tplData[self::FLD_ICON_DIR] = $iconDir;
    }

    private function setMsgData()
    {
        $this->tplData[self::FLD_ERR_MSGS] =
                UserLogger::getUiMsgs(UserLogger::UI_ERR);
        $this->tplData[self::FLD_SUCC_MSGS] =
                UserLogger::getUiMsgs(UserLogger::UI_SUCC);
    }

    /**
     *
     * @return string
     */
    public function getTpl()
    {
        return realpath(__DIR__ . '/../Tpl') . '/Main.tpl';
    }

}
