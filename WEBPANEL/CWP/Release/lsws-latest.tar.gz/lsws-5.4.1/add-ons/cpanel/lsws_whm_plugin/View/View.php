<?php

/* * ******************************************
 * LiteSpeed Web Server Plugin for WHM
 * @Author: LiteSpeed Technologies, Inc. (https://www.litespeedtech.com)
 * @Copyright: (c) 2018-2019
 * ******************************************* */

namespace LsPanel\View;

use \Lsc\Wp\Context\Context;
use \Lsc\Wp\LSCMException;
use \Lsc\Wp\Logger;

class View
{

    /**
     * @var object
     */
    private $viewModel;

    /**
     * @var string
     */
    private $panelViewDir = __DIR__;

    /**
     *
     * @param object  $viewModel
     */
    public function __construct( $viewModel )
    {
        $this->viewModel = $viewModel;
    }

    public function display()
    {
        $this->loadTpl($this->viewModel->getTpl());
    }

    /**
     *
     * @param string  $tplPath
     * @throws LSCMException
     */
    private function loadTpl( $tplPath )
    {
        $tplFile = basename($tplPath);
        $custTpl = "{$this->panelViewDir}/Tpl/Cust/{$tplFile}";

        if ( file_exists($custTpl) ) {
            include $custTpl;
        }
        elseif ( file_exists($tplPath) ) {
            include $tplPath;
        }
        else {
            throw new LSCMException("Could not load page template {$tplPath}.");
        }
    }

    /**
     * Used by the page template to load sub-template blocks.
     *
     * @param string  $tplName
     * @param array   $d        Sub-template data.
     * @param bool    $shared   True if block tpl is found in shared directory.
     * @return null
     * @throws LSCMException
     */
    private function loadTplBlock( $tplName, $d, $shared = false )
    {
        $custTpl = "{$this->panelViewDir}/Tpl/Cust/Blocks/{$tplName}";

        if ( file_exists($custTpl) ) {
            include $custTpl;
            return;
        }

        if ( $shared ) {

            try {
                $sharedTplDir = Context::getOption()->getSharedTplDir();
                $tplPath = "{$sharedTplDir}/Blocks/{$tplName}";
            }
            catch ( LSCMException $e ) {
                $msg = $e->getMessage() . ' Unable to get shared template directory.';
                Logger::error($msg);

                throw new LSCMException($msg);
            }
        }
        else {
            $tplPath = $this->panelViewDir . "/Tpl/Blocks/{$tplName}";
        }

        if ( file_exists($tplPath) ) {
            include $tplPath;
        }
        else {
            throw new LSCMException("Could not load block template {$tplPath}.");
        }
    }

}
