<?php

/* * *********************************************
 * LiteSpeed Web Server WordPress Dash Notifier
 * @Author: LiteSpeed Technologies, Inc. (https://www.litespeedtech.com)
 * @Copyright: (c) 2019
 * *******************************************
 */

namespace Lsc\Wp;

use \Lsc\Wp\Logger;
use \Lsc\Wp\LSCMException;

class DashNotifier
{

    const DEFAULT_PLUGIN_PATH = '/wp-content/plugins/dash-notifier';
    const DOWNLOAD_DIR = '/usr/src/litespeed-wp-plugin';
    const DASH_PLUGIN = 'dash-notifier/dash-notifier.php';
    const PLUGIN_NAME = 'dash-notifier';
    const DASH_MD5 = 'dash_md5';
    const BYPASS_FLAG = '.dash_notifier_bypass';

    private function __construct()
    {

    }

    /**
     * Check if WordPress installation should be notified using the Dash
     * Notifier plugin.
     *
     * @param string  $wpPath  WordPress installation root directory.
     * @return boolean
     */
    public static function canNotify( $wpPath )
    {
        if ( file_exists("{$wpPath}/" . self::BYPASS_FLAG) ) {
            return false;
        }

        return true;
    }

    /**
     * Checks the current installation for existing LSCWP plugin files and
     * copies them to the installation's plugins directory if not found.
     * This function should only be run as the user.
     *
     * @return boolean            True when new Dash Notifier plugin files are
     *                             used.
     * @throws LSCMException
     */
    public static function prepareUserInstall()
    {
        $pluginDir = WP_PLUGIN_DIR;

        $dashNotifierPlugin = "{$pluginDir}/dash-notifier/dash-notifier.php";

        if ( file_exists($dashNotifierPlugin) ) {
            /**
             * Existing installation detected.
             */
            return false;
        }

        $pluginSrc = self::DOWNLOAD_DIR . '/' . self::PLUGIN_NAME;
        exec("/bin/cp -rf {$pluginSrc} {$pluginDir}");

        if ( !file_exists($dashNotifierPlugin) ) {
            throw new LSCMException("Failed to copy Dash Notifier plugin files to "
            . "{$pluginDir}.", LSCMException::E_NON_FATAL);
        }

        Logger::debug("Copied Dash Notifier plugin files into plugins directory {$pluginDir}");

        return true;
    }

    /**
     * Activate Dash Notifier plugin if it is not already activated, and give
     * the plugin any notification data in the form of a JSON encoded array.
     *
     * @param string  $jsonInfo  Dash Notifier plugin info.
     * @return boolean
     * @throws LSCMException
     */
    public static function doNotify ( $jsonInfo ) {

        if ( file_exists(WP_PLUGIN_DIR . '/' . self::DASH_PLUGIN) ) {

            /**
             * Used to pass info to the Dash Notifier Plugin.
             */
            define( 'DASH_NOTIFIER_MSG', $jsonInfo);

            if ( !is_plugin_active(self::DASH_PLUGIN) ) {

                /**
                * Should not check directly, can error on success due to object
                * cache.
                */
               activate_plugin(self::DASH_PLUGIN, '', false, false);

               if ( !is_plugin_active(self::DASH_PLUGIN) ) {
                   return false;
               }
            }
            else {
                include WP_PLUGIN_DIR . '/' . self::DASH_PLUGIN;
            }
        }
        else {
            throw new LSCMException('Dash Notifier plugin files are missing. Cannot notify.',
                    LSCMException::E_NON_FATAL);
        }

        return true;
    }

    /**
     * WP Functions: deactivate_plugins(), delete_plugins()
     *
     * @param boolean  $uninstall
     */
    public static function deactivate( $uninstall )
    {
        deactivate_plugins(self::DASH_PLUGIN);

        if ( $uninstall ) {
            //add some msg about having removed plugin files?
            delete_plugins(array( self::DASH_PLUGIN ));
        }
    }

}
