# Note to Github users
* Pull requests will only be accepted for bugfixes. No new features please.
* Please mention a ticket id in your pull request. If there is no ticket for that particular bug yet, go and create an issue request first, and fill out all fields of the issue template.
